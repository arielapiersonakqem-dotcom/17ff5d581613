// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Render tanager plumage\n", stdout);
  return lionss_run_workload("Tanager");
}
