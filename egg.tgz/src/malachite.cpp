// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Render malachite swirl"); }
int main(){
  announce();
  return lionss_run_workload("malachite");
}
