// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Prune snapshots"); }
int main(){
  announce();
  return lionss_run_workload("restic_prune");
}
