// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode and checksum\n", stdout);
  return lionss_run_workload("flac_md5");
}
