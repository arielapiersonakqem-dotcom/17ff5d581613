// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Run long self-test\n", stdout);
  return lionss_run_workload("smartctl_long");
}
