// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fold secondary structure"); }
int main(){
  announce();
  return lionss_run_workload("rnaFold");
}
